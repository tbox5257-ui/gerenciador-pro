# Gerenciador Pro - APK Android

Aplicativo Android para gerenciar clientes com sincronização via GitHub Gist.

## 🚀 Início Rápido

### Pré-requisitos
- Node.js 18+
- Java JDK 17
- Android SDK 30+
- Git

### Instalação Local

```bash
# Clone o repositório
git clone https://github.com/seu-usuario/gerenciador-pro.git
cd gerenciador-pro

# Instale as dependências
npm install

# Compile com Vite
npm run build

# Inicialize Capacitor
npx cap init "Gerenciador Pro" br.com.gerenciadorpro --web-dir dist

# Adicione a plataforma Android
npx cap add android

# Sincronize os assets
npx cap sync android

# Compile o APK
cd android
./gradlew assembleDebug

# O APK estará em: android/app/build/outputs/apk/debug/app-debug.apk
```

## 🤖 Compilação Automática com GitHub Actions

Este repositório inclui um workflow automático que compila o APK a cada push.

### Como funciona:
1. Faça push para `main`, `master` ou `develop`
2. O GitHub Actions compila automaticamente
3. O APK fica disponível para download em **Actions → Artifacts**

### Para baixar o APK:
1. Vá para a aba **Actions**
2. Clique no workflow mais recente
3. Clique em **Artifacts** → `app-debug`
4. Baixe o arquivo `app-debug.apk`

## 📱 Instalação no Celular

### Via ADB (Android Debug Bridge):
```bash
adb install -r app-debug.apk
```

### Via Transferência Direta:
1. Copie o `app-debug.apk` para seu celular
2. Abra o gerenciador de arquivos
3. Toque no arquivo
4. Clique em "Instalar"

## 🔧 Configuração

### GitHub Gist
O app sincroniza dados com um GitHub Gist. Configure em `src/App.jsx`:

```javascript
const GITHUB_TOKEN = "seu_token_aqui";
const GIST_ID = "seu_gist_id_aqui";
```

### Obter Token GitHub:
1. Vá para https://github.com/settings/tokens
2. Clique em "Generate new token (classic)"
3. Selecione `gist` como escopo
4. Copie o token e cole em `src/App.jsx`

## 📋 Estrutura do Projeto

```
gerenciador-pro/
├── .github/
│   └── workflows/
│       └── build-apk.yml          ← Workflow GitHub Actions
├── src/
│   ├── App.jsx                    ← Componente principal
│   └── main.jsx                   ← Entrada React
├── android/                       ← Projeto Android (Capacitor)
├── dist/                          ← Build Vite
├── package.json
├── vite.config.js
├── capacitor.config.json
└── index.html
```

## 🎯 Funcionalidades

- ✅ Gerenciar clientes (CRUD)
- ✅ Sincronizar com GitHub Gist
- ✅ Armazenamento local (localStorage)
- ✅ Enviar mensagens WhatsApp
- ✅ Calcular vencimentos
- ✅ Tema claro/escuro

## 🐛 Troubleshooting

### APK não compila no GitHub Actions
1. Verifique se o `build.gradle` está correto
2. Certifique-se de que `ANDROID_HOME` está configurado
3. Verifique as licenças do Android SDK

### App não abre no celular
1. Verifique se o celular tem Android 5.0+ (API 22+)
2. Ative "Fontes desconhecidas" nas configurações
3. Tente desinstalar versões antigas antes de instalar

## 📄 Licença

MIT

## 👤 Autor

Desenvolvido com Manus
Data: 14/03/2026

---

**Dúvidas?** Abra uma issue no GitHub!
