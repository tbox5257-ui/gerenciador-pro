# 📖 Instruções Completas - Gerenciador Pro

## Passo 1: Criar Repositório no GitHub

1. Acesse https://github.com/new
2. Preencha:
   - **Repository name:** `gerenciador-pro`
   - **Description:** `Aplicativo Android para gerenciar clientes`
   - **Public** (recomendado para usar GitHub Actions gratuito)
3. Clique em **Create repository**

## Passo 2: Fazer Upload dos Arquivos

### Opção A: Via Git (Recomendado)

```bash
# Clone o repositório vazio
git clone https://github.com/seu-usuario/gerenciador-pro.git
cd gerenciador-pro

# Copie todos os arquivos deste projeto para a pasta
# (Copie tudo exceto node_modules e .gradle)

# Adicione os arquivos
git add .

# Faça commit
git commit -m "Initial commit: Gerenciador Pro com GitHub Actions"

# Faça push
git push origin main
```

### Opção B: Via GitHub Web (Simples)

1. Vá para seu repositório no GitHub
2. Clique em **Add file** → **Upload files**
3. Arraste os arquivos (exceto `node_modules` e `android/.gradle`)
4. Clique em **Commit changes**

## Passo 3: Ativar GitHub Actions

1. Vá para a aba **Actions** do seu repositório
2. Clique em **I understand my workflows, go ahead and enable them**
3. Pronto! O workflow está ativo

## Passo 4: Compilar o APK

### Opção A: Automático (Recomendado)

1. Faça qualquer alteração no código
2. Faça commit e push:
   ```bash
   git add .
   git commit -m "Atualização"
   git push origin main
   ```
3. Vá para **Actions** → Veja o workflow compilando
4. Quando terminar, clique em **Artifacts** → `app-debug` para baixar

### Opção B: Manual (Workflow Dispatch)

1. Vá para **Actions**
2. Clique em **Build APK Android**
3. Clique em **Run workflow** → **Run workflow**
4. Aguarde a compilação
5. Baixe o APK em **Artifacts**

## Passo 5: Instalar no Celular

### Via ADB:
```bash
adb install -r app-debug.apk
```

### Via Transferência Direta:
1. Copie o arquivo para seu celular (USB, Bluetooth, email, etc.)
2. Abra o gerenciador de arquivos
3. Toque no arquivo
4. Clique em "Instalar"

## 🔧 Configuração Avançada

### Usar Token GitHub Pessoal

Se quiser usar um token específico (não recomendado para público):

1. Vá para https://github.com/settings/tokens
2. Clique em **Generate new token (classic)**
3. Selecione `gist` como escopo
4. Copie o token
5. Vá para seu repositório → **Settings** → **Secrets and variables** → **Actions**
6. Clique em **New repository secret**
7. Nome: `GITHUB_TOKEN_GIST`
8. Valor: Cole seu token
9. Edite `src/App.jsx` e use: `const GITHUB_TOKEN = process.env.GITHUB_TOKEN_GIST || "seu_token_aqui";`

### Assinar APK (Release)

Para criar versões assinadas:

1. Gere uma keystore:
   ```bash
   keytool -genkey -v -keystore my-release-key.jks -keyalg RSA -keysize 2048 -validity 10000 -alias my-key-alias
   ```

2. Adicione à **Settings** → **Secrets**:
   - `KEYSTORE_FILE`: Conteúdo do arquivo .jks em base64
   - `KEYSTORE_PASSWORD`: Senha da keystore
   - `KEY_ALIAS`: Nome da chave
   - `KEY_PASSWORD`: Senha da chave

3. Modifique o workflow para assinar o APK

## 📊 Monitorar Compilações

1. Vá para **Actions**
2. Veja o histórico de compilações
3. Clique em uma compilação para ver logs detalhados
4. Se falhar, veja a mensagem de erro e corrija

## 🆘 Troubleshooting

### Workflow não inicia
- Verifique se você fez push para `main`, `master` ou `develop`
- Verifique se o arquivo `.github/workflows/build-apk.yml` está no repositório

### Compilação falha
1. Vá para **Actions** → Clique no workflow
2. Veja a mensagem de erro
3. Corrija o código localmente
4. Faça push novamente

### APK não instala no celular
- Desinstale versões antigas: `adb uninstall br.com.gerenciadorpro`
- Verifique se o celular tem Android 5.0+
- Ative "Fontes desconhecidas" nas configurações

## 📝 Próximas Etapas

1. **Configurar GitHub Gist**: Edite `src/App.jsx` com seu token e Gist ID
2. **Testar localmente**: Execute `npm install && npm run build`
3. **Fazer push**: Envie para GitHub e veja a compilação automática
4. **Instalar no celular**: Baixe o APK e instale

---

**Pronto!** Seu app está compilando automaticamente no GitHub Actions! 🎉
