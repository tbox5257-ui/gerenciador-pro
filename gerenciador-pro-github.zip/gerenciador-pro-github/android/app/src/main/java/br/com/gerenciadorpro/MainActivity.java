package br.com.gerenciadorpro;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
