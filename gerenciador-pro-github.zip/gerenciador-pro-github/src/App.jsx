import { useState, useEffect, useCallback, useRef } from "react";

// ═══════════════════════════════════════
//  CONFIG
// ═══════════════════════════════════════
const GITHUB_TOKEN = "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";
const GIST_ID      = "eff93d9051670061dcc6a8b57e397407";
const CLOUD_FILE   = "gm_cloud_backup.json";
const LOCAL_KEY    = "gm_clientes_v1";
const IMP_KEY      = "gm_imported_ids";
const PAG_KEY      = "gm_pagamentos_v1";
const TEMA_KEY     = "gm_tema_v1";
const SYNC_MODE_KEY = "gm_sync_mode_v1"; // "auto" | "manual"
const SYNC_MS      = 30000;

// ═══════════════════════════════════════
//  HELPERS
// ═══════════════════════════════════════
const lsGet = k => { try { const r = localStorage.getItem(k); return r ? JSON.parse(r) : null; } catch { return null; } };
const lsSet = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} };
const genId = () => "c_" + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
const norm  = s => (s || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/\s+/g, " ").trim();
const todayISO = () => new Date().toISOString().split("T")[0];

const dmyToISO = s => {
  if (!s) return "";
  if (/^\d{4}-\d{2}-\d{2}$/.test(s)) return s;
  const p = s.split("/");
  return p.length === 3 ? `${p[2]}-${p[1].padStart(2,"0")}-${p[0].padStart(2,"0")}` : s;
};
const fmtDate = s => {
  if (!s) return "";
  if (s.includes("/")) return s;
  const [y, m, d] = s.split("-");
  return `${d}/${m}/${y}`;
};
const fmtBRL = v => {
  if (!v) return "";
  const n = parseFloat(String(v).replace(/[^\d.,]/g, "").replace(",", "."));
  return isNaN(n) ? String(v) : `R$ ${n.toFixed(2).replace(".", ",")}`;
};
const fmtTel = t => {
  const d = String(t || "").replace(/\D/g, "");
  if (d.length === 11) return `(${d.slice(0,2)}) ${d.slice(2,7)}-${d.slice(7)}`;
  if (d.length === 10) return `(${d.slice(0,2)}) ${d.slice(2,6)}-${d.slice(6)}`;
  return t || "";
};

// Urgência de vencimento
const diffDias = iso => {
  if (!iso) return null;
  const hoje = new Date(); hoje.setHours(0,0,0,0);
  const d = new Date(dmyToISO(iso)); d.setHours(0,0,0,0);
  return Math.ceil((d - hoje) / 86400000);
};
const calcVenc = iso => {
  const d = diffDias(iso);
  if (d === null) return "";
  if (d < 0)  return "vencido";
  if (d === 0) return "hoje";
  if (d === 1) return "amanha";
  if (d <= 3)  return "3dias";
  return "";
};
const VC = { vencido:"#ef4444", hoje:"#f97316", amanha:"#eab308", "3dias":"#a855f7", "":"#22c55e" };
const VL = { vencido:"ATRASADO", hoje:"HOJE", amanha:"AMANHÃ", "3dias":"3 DIAS", "":"ATIVO" };

// ═══════════════════════════════════════
//  WHATSAPP
// ═══════════════════════════════════════
// Tabela de valores por plano (espelha mensagem_whatsapp_atualizado_2.js)
const getValorPlano = plano => {
  if (!plano) return "";
  const p = plano.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g,"").replace(/\s+/g," ").trim();
  if (p.includes("4 meses") && p.includes("1 tela") && p.includes("family")) return "R$ 20,00";
  if (p.includes("3 meses") && p.includes("1 tela") && p.includes("premium")) return "R$ 50,00";
  if (p.includes("3 meses") && p.includes("1 tela") && p.includes("vip"))     return "R$ 40,00";
  if (p.includes("3 meses") && p.includes("2 telas"))                          return "R$ 100,00";
  if (p.includes("3 meses") && p.includes("1 tela"))                           return "R$ 55,00";
  if (p.includes("2 meses") && p.includes("2 telas"))                          return "R$ 65,00";
  if (p.includes("2 meses") && p.includes("1 tela"))                           return "R$ 35,00";
  if (p.includes("mensal") && p.includes("5 telas") && p.includes("vip"))     return "R$ 70,00";
  if (p.includes("mensal") && p.includes("3 telas") && p.includes("vip"))     return "R$ 40,00";
  if (p.includes("mensal") && p.includes("2 telas") && p.includes("vip"))     return "R$ 30,00";
  if (p.includes("mensal") && p.includes("1 tela")  && p.includes("vip"))     return "R$ 15,00";
  if (p.includes("mensal") && p.includes("2 telas") && p.includes("plus"))    return "R$ 20,00";
  if (p.includes("mensal") && p.includes("1 tela")  && p.includes("plus"))    return "R$ 10,00";
  if (p.includes("mensal") && p.includes("2 telas") && p.includes("family"))  return "R$ 10,00";
  if (p.includes("mensal") && p.includes("1 tela")  && p.includes("family"))  return "R$ 5,00";
  if (p.includes("mensal") && p.includes("3 telas"))                           return "R$ 50,00";
  if (p.includes("mensal") && p.includes("2 telas"))                           return "R$ 35,00";
  if (p.includes("mensal") && p.includes("1 tela"))                            return "R$ 20,00";
  if (p.includes("semestral"))  return "R$ 120,00";
  if (p.includes("trimestral")) return "R$ 65,00";
  if (p.includes("anual"))      return "R$ 220,00";
  return "";
};

// Gera e abre mensagem de cobrança no WhatsApp
const abrirWhatsApp = c => {
  const tel = (c.tel || "").replace(/\D/g, "");
  if (!tel || tel.length < 10) { alert("Telefone não cadastrado para este cliente."); return; }

  const venc  = calcVenc(c.dataVenc);
  const valor = c.valor || getValorPlano(c.plano) || "";
  const dias  = diffDias(c.dataVenc);

  let alerta = "";
  if (venc === "vencido") {
    const qtd = dias !== null ? Math.abs(dias) : "";
    alerta = `⚠️ *SUA MENSALIDADE ESTÁ ${qtd ? qtd + " DIA(S) " : ""}ATRASADA!*\n\n`;
  } else if (venc === "hoje")   alerta = "⚠️ *SUA MENSALIDADE VENCE HOJE!*\n\n";
  else if (venc === "amanha")   alerta = "⚠️ *SUA MENSALIDADE VENCE AMANHÃ!*\n\n";
  else if (venc === "3dias")    alerta = "⚠️ *SUA MENSALIDADE VENCERÁ EM BREVE!*\n\n";

  const usuario  = c.usuario ? `@${c.usuario}` : c.nome;
  const msg =
`👋 *Olá, tudo bem?*
📺 *Temos um lembrete à respeito do nosso serviço de Canais, Filmes e Séries:*

${alerta}👤 *Usuário(s):* ${usuario}
📅 *Vencimento:* ${fmtDate(c.dataVenc)}${c.plano ? `\n📦 *Plano Atual:* ${c.plano}` : ""}${valor ? `\n💰 *Valor:* ${valor}` : ""}`;

  // Garante DDD+número com 55 na frente
  const phone = tel.startsWith("55") ? tel : `55${tel}`;
  window.open(`https://api.whatsapp.com/send?phone=${phone}&text=${encodeURIComponent(msg)}`, "_blank");
};

// Cor do botão WhatsApp por urgência
const wppCor = venc => {
  if (venc === "vencido") return "#ef4444";
  if (venc === "hoje")    return "#f97316";
  if (venc === "amanha" || venc === "3dias") return "#a855f7";
  return "#25D366";
};

// ═══════════════════════════════════════
//  GIST API
// ═══════════════════════════════════════
async function gistGet() {
  try {
    const r = await fetch(`https://api.github.com/gists/${GIST_ID}`, {
      headers: { Authorization: `token ${GITHUB_TOKEN}`, Accept: "application/vnd.github.v3+json" }
    });
    if (!r.ok) return null;
    const data = await r.json();
    const content = data.files?.[CLOUD_FILE]?.content;
    return content ? JSON.parse(content) : null;
  } catch { return null; }
}
async function gistPatch(payload) {
  try {
    const r = await fetch(`https://api.github.com/gists/${GIST_ID}`, {
      method: "PATCH",
      headers: { Authorization: `token ${GITHUB_TOKEN}`, "Content-Type": "application/json" },
      body: JSON.stringify({ files: { [CLOUD_FILE]: { content: JSON.stringify(payload) } } })
    });
    return r.ok;
  } catch { return false; }
}

// ═══════════════════════════════════════
//  ANÁLISE DE IMPORTAÇÃO
// ═══════════════════════════════════════
// Extrai timestamp numérico de um cliente — suporta campo "ts" (extensão) ou "updatedAt" (ISO)
const getTs = c => {
  if (c?.ts && typeof c.ts === "number") return c.ts;
  if (c?.updatedAt) return new Date(c.updatedAt).getTime() || 0;
  return 0;
};

// Normaliza cliente vindo da nuvem (extensão BoxTV) para o formato interno do app
// A extensão pode salvar: dataVenc em DD/MM/YYYY, tel com +55, login em vez de usuario,
// venc desatualizado (recalculamos), ts numérico em vez de updatedAt
const normalizarCloudCliente = c => {
  const dataVencISO = dmyToISO(c.dataVenc || "");                        // DD/MM/YYYY → YYYY-MM-DD
  const tel         = (c.tel || "").replace(/\D/g,"").replace(/^55/,"").slice(-11); // remove +55
  const usuario     = c.usuario || c.login || "";                        // extensão pode usar "login"
  const updatedAt   = c.updatedAt || (c.ts ? new Date(c.ts).toISOString() : ""); // ts numérico → ISO
  return {
    ...c,
    dataVenc:  dataVencISO,
    tel,
    usuario,
    updatedAt,
    venc: calcVenc(dataVencISO),   // recalcula sempre — não confiar no valor salvo pela extensão
    // campos extras da extensão — preserva se existirem
    fornecedor:  c.fornecedor  || "",
    renovadoAte: c.renovadoAte || "",
    obs:         c.obs         || "",
  };
};

function analisarImportacao(cloudObj, localObj, importedIds) {
  const imp      = new Set(importedIds || []);
  const localArr = Object.values(localObj || {});
  const novos = [], atualizados = [], duplicados = [];
  // Rastreia chaves nuvem já processadas nesta rodada (evita duplicatas dentro do próprio Gist)
  const processados = new Set();

  Object.entries(cloudObj || {}).forEach(([id, c]) => {
    if (!c.nome && !c.tel) return;
    if (processados.has(id)) return;
    processados.add(id);

    const cn    = normalizarCloudCliente(c);
    const telC  = norm(cn.tel  || "");
    const nomeC = norm(cn.nome || "");

    // ── Camada 1: já foi importado por _cloudId (chave exata do Gist)
    if (imp.has(id)) {
      const local = localArr.find(l => l._cloudId === id);
      if (getTs(c) > getTs(local)) atualizados.push({ ...cn, _cloudId: id });
      else duplicados.push({ ...cn, _cloudId: id });
      return;
    }

    // ── Camada 2: já existe localmente com este _cloudId (importado antes de gravar IMP_KEY)
    const porCloudId = localArr.find(l => l._cloudId === id);
    if (porCloudId) {
      if (getTs(c) > getTs(porCloudId)) atualizados.push({ ...cn, _cloudId: id });
      else duplicados.push({ ...cn, _cloudId: id });
      return;
    }

    // ── Camada 3: mesmo telefone OU mesmo nome já existe localmente
    const porTel  = telC.length >= 10 && localArr.find(l =>
      norm((l.tel || "").replace(/\D/g, "").slice(-11)) === telC);
    const porNome = nomeC.length >= 4 && localArr.find(l =>
      norm(l.nome || "") === nomeC);
    const localMatch = porTel || porNome;

    if (localMatch) {
      // Existe localmente mas com chave diferente — trata como atualização se nuvem for mais novo
      if (getTs(c) > getTs(localMatch)) atualizados.push({ ...cn, _cloudId: id });
      else duplicados.push({ ...cn, _cloudId: id });
      return;
    }

    // ── Novo de verdade
    novos.push({ ...cn, _cloudId: id });
  });

  const ord  = { vencido:0, hoje:1, amanha:2, "3dias":3, "":4 };
  const sort = arr => arr.sort((a,b) => (ord[calcVenc(a.dataVenc)]??4)-(ord[calcVenc(b.dataVenc)]??4));
  return { novos: sort(novos), atualizados: sort(atualizados), duplicados: sort(duplicados), totalNuvem: Object.keys(cloudObj||{}).length };
}

// ═══════════════════════════════════════
//  SISTEMA 🔥 FOGO — WHATSAPP
// ═══════════════════════════════════════
// ═══════════════════════════════════════
//  TEMAS
// ═══════════════════════════════════════
const TEMAS = [
  { id:"padrao",      nome:"Padrão",       emoji:"🌱", desc:"Verde clássico",
    preview:["#16a34a","#f0fdf4","#15803d"],
    vars:{ "--t-pri":"#16a34a","--t-dark":"#15803d","--t-bg":"#f0f2f5","--t-card":"#ffffff",
           "--t-txt":"#111111","--t-txt2":"#666666","--t-bor":"#e5e7eb","--t-hdr":"#ffffff",
           "--t-fab":"linear-gradient(135deg,#16a34a,#15803d)","--t-dark-mode":"0",
           "--t-r":"14px","--t-font":"system-ui,sans-serif" } },
  { id:"flamengo",    nome:"Flamengo",     emoji:"🦅", desc:"Rubro-Negro, Nação!",
    preview:["#e3000f","#1a0000","#ffcc00"],
    vars:{ "--t-pri":"#e3000f","--t-dark":"#aa0000","--t-bg":"#1a0000","--t-card":"#2a0000",
           "--t-txt":"#ffffff","--t-txt2":"#ffaaaa","--t-bor":"#550000","--t-hdr":"#0d0000",
           "--t-fab":"linear-gradient(135deg,#e3000f,#aa0000)","--t-dark-mode":"1",
           "--t-r":"4px","--t-font":"Georgia,serif" } },
  { id:"palmeiras",   nome:"Palmeiras",    emoji:"🌴", desc:"Verdão do Brasil!",
    preview:["#006437","#001a0d","#ffffff"],
    vars:{ "--t-pri":"#006437","--t-dark":"#004d29","--t-bg":"#001a0d","--t-card":"#002a14",
           "--t-txt":"#ffffff","--t-txt2":"#99ccaa","--t-bor":"#004422","--t-hdr":"#001208",
           "--t-fab":"linear-gradient(135deg,#006437,#004d29)","--t-dark-mode":"1",
           "--t-r":"0px","--t-font":"Trebuchet MS,sans-serif" } },
  { id:"corinthians", nome:"Corinthians",  emoji:"👊", desc:"Timão! Fiel!",
    preview:["#ffffff","#0a0a0a","#444444"],
    vars:{ "--t-pri":"#ffffff","--t-dark":"#cccccc","--t-bg":"#0a0a0a","--t-card":"#1a1a1a",
           "--t-txt":"#ffffff","--t-txt2":"#aaaaaa","--t-bor":"#333333","--t-hdr":"#000000",
           "--t-fab":"linear-gradient(135deg,#555,#111)","--t-dark-mode":"1",
           "--t-r":"2px","--t-font":"Impact,sans-serif" } },
  { id:"sao_paulo",   nome:"São Paulo",    emoji:"🔱", desc:"Tricolor Morumbi",
    preview:["#cc0000","#f5f5f5","#000000"],
    vars:{ "--t-pri":"#cc0000","--t-dark":"#990000","--t-bg":"#f5f5f5","--t-card":"#ffffff",
           "--t-txt":"#111111","--t-txt2":"#555555","--t-bor":"#dddddd","--t-hdr":"#ffffff",
           "--t-fab":"linear-gradient(135deg,#cc0000,#990000)","--t-dark-mode":"0",
           "--t-r":"50px","--t-font":"Helvetica Neue,sans-serif" } },
  { id:"brasil",      nome:"Seleção 🇧🇷",  emoji:"⭐", desc:"Canarinho! 5★",
    preview:["#009c3b","#002776","#ffdf00"],
    vars:{ "--t-pri":"#ffdf00","--t-dark":"#ccb800","--t-bg":"#002776","--t-card":"#003299",
           "--t-txt":"#ffffff","--t-txt2":"#aaccff","--t-bor":"#004ccc","--t-hdr":"#001a55",
           "--t-fab":"linear-gradient(135deg,#009c3b,#007a2f)","--t-dark-mode":"1",
           "--t-r":"50px","--t-font":"Verdana,sans-serif" } },
  { id:"neon",        nome:"Neon Field",   emoji:"🏟️", desc:"Estádio noturno",
    preview:["#00ff88","#050510","#ff00aa"],
    vars:{ "--t-pri":"#00ff88","--t-dark":"#00cc66","--t-bg":"#050510","--t-card":"#0d0d22",
           "--t-txt":"#ffffff","--t-txt2":"#8888cc","--t-bor":"#1a1a44","--t-hdr":"#070715",
           "--t-fab":"linear-gradient(135deg,#00ff88,#ff00aa)","--t-dark-mode":"1",
           "--t-r":"6px","--t-font":"Courier New,monospace" } },
  { id:"gold",        nome:"Campeão",      emoji:"🏆", desc:"Ouro puro",
    preview:["#f59e0b","#0d0900","#d97706"],
    vars:{ "--t-pri":"#f59e0b","--t-dark":"#d97706","--t-bg":"#0d0900","--t-card":"#1a1200",
           "--t-txt":"#ffd700","--t-txt2":"#aa8800","--t-bor":"#332200","--t-hdr":"#080600",
           "--t-fab":"linear-gradient(135deg,#f59e0b,#d97706)","--t-dark-mode":"1",
           "--t-r":"8px","--t-font":"Georgia,serif" } },
  { id:"atletico_mg", nome:"Atlético-MG",  emoji:"🐓", desc:"Galo! Gigante!",
    preview:["#c0a000","#0a0a0a","#ffffff"],
    vars:{ "--t-pri":"#c0a000","--t-dark":"#8a7200","--t-bg":"#0a0a0a","--t-card":"#161616",
           "--t-txt":"#ffffff","--t-txt2":"#888888","--t-bor":"#2a2a2a","--t-hdr":"#050505",
           "--t-fab":"linear-gradient(135deg,#c0a000,#8a7200)","--t-dark-mode":"1",
           "--t-r":"6px","--t-font":"Arial Black,sans-serif" } },
];

function getTema() {
  try { const id = localStorage.getItem(TEMA_KEY); return TEMAS.find(t=>t.id===id)||TEMAS[0]; }
  catch { return TEMAS[0]; }
}
function aplicarTema(t) {
  try {
    const r = document.documentElement;
    Object.entries(t.vars).forEach(([k,v]) => r.style.setProperty(k, v));
    localStorage.setItem(TEMA_KEY, t.id);
  } catch {}
}

// ═══════════════════════════════════════
//  ÍCONES SVG
// ═══════════════════════════════════════
const Ic = ({ n, sz=18, col="currentColor" }) => {
  const paths = {
    edit:      "M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7M18.5 2.5a2.12 2.12 0 0 1 3 3L12 15l-4 1 1-4z",
    trash:     "M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6",
    plus:      "M12 5v14M5 12h14",
    close:     "M18 6L6 18M6 6l12 12",
    search:    "M21 21l-4.35-4.35M17 11A6 6 0 1 1 5 11a6 6 0 0 1 12 0z",
    cloud:     "M18 10h-1.26A8 8 0 1 0 9 20h9a5 5 0 0 0 0-10z",
    download:  "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3",
    check:     "M20 6L9 17l-5-5",
    gear:      "M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z",
    calendar:  "M3 9h18M3 15h18M8 3v3M16 3v3M4 5h16a1 1 0 0 1 1 1v14a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1z",
    refresh:   "M23 4v6h-6M1 20v-6h6M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15",
    user:      "M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2M12 3a4 4 0 1 0 0 8 4 4 0 0 0 0-8z",
    users:     "M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2M9 7a4 4 0 1 0 0 8 4 4 0 0 0 0-8zM23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75",
    card:      "M1 4h22v16H1zM1 10h22",
    back:      "M19 12H5M12 5l-7 7 7 7",
  };
  return (
    <svg width={sz} height={sz} viewBox="0 0 24 24" fill="none"
         stroke={col} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      {(paths[n]||"").split("M").filter(Boolean).map((p,i)=>(
        <path key={i} d={"M"+p}/>
      ))}
    </svg>
  );
};

// ═══════════════════════════════════════
//  BADGE + COR urgência
// ═══════════════════════════════════════
function BadgeVenc({ dataVenc, size=11 }) {
  const v = calcVenc(dataVenc);
  const cor = VC[v] || "#22c55e";
  const label = VL[v] || "ATIVO";
  return (
    <span style={{
      fontSize: size, fontWeight:800,
      color: cor, background: cor+"20",
      padding:"3px 9px", borderRadius:20, letterSpacing:.3, whiteSpace:"nowrap",
      border:`1px solid ${cor}44`,
    }}>
      {label}
    </span>
  );
}

// ═══════════════════════════════════════
//  MODAL TEMAS
// ═══════════════════════════════════════
function ModalTemas({ onFechar }) {
  const [ativo, setAtivo] = useState(()=>getTema().id);
  const [hover, setHover] = useState(null);
  const temaVis = hover ? TEMAS.find(t=>t.id===hover) : TEMAS.find(t=>t.id===ativo) || TEMAS[0];

  const aplicar = t => { setAtivo(t.id); aplicarTema(t); };

  return (
    <div style={{ position:"fixed",inset:0,zIndex:800,background:"rgba(0,0,0,.7)",
                  display:"flex",alignItems:"flex-end" }}
         onClick={e=>e.target===e.currentTarget&&onFechar()}>
      <div style={{ width:"100%",maxWidth:440,margin:"0 auto",background:"#fff",
                    borderRadius:"20px 20px 0 0",maxHeight:"88vh",overflowY:"auto" }}>
        <div style={{ display:"flex",justifyContent:"center",padding:"10px 0 4px" }}>
          <div style={{ width:36,height:4,borderRadius:2,background:"#e5e7eb" }}/>
        </div>
        <div style={{ padding:"8px 18px 14px",display:"flex",alignItems:"center",
                      justifyContent:"space-between",borderBottom:"1px solid #f0f0f0" }}>
          <p style={{ margin:0,fontSize:17,fontWeight:800,color:"#111" }}>🎨 Temas</p>
          <button onClick={onFechar} style={{ background:"#f3f4f6",border:"none",
            borderRadius:"50%",width:32,height:32,cursor:"pointer",
            display:"flex",alignItems:"center",justifyContent:"center" }}>
            <Ic n="close" sz={14} col="#666"/>
          </button>
        </div>

        {/* Mini preview */}
        <div style={{ margin:"12px 18px 0",borderRadius:14,overflow:"hidden",
                      border:`1.5px solid ${temaVis.vars["--t-pri"]}44`,transition:"all .2s" }}>
          <div style={{ background:temaVis.vars["--t-hdr"],padding:"10px 14px",
                        display:"flex",alignItems:"center",gap:8 }}>
            <span style={{ fontSize:16 }}>{temaVis.emoji}</span>
            <span style={{ fontSize:14,fontWeight:800,color:temaVis.vars["--t-txt"],
                           fontFamily:temaVis.vars["--t-font"] }}>{temaVis.nome}</span>
          </div>
          <div style={{ background:temaVis.vars["--t-bg"],padding:"8px 14px",display:"flex",gap:8 }}>
            {["Home","Calendário","Resumo"].map((t,i)=>(
              <span key={t} style={{ fontSize:12,fontWeight:i===0?800:500,
                color:i===0?temaVis.vars["--t-pri"]:temaVis.vars["--t-txt2"],
                fontFamily:temaVis.vars["--t-font"],
                borderBottom:i===0?`2px solid ${temaVis.vars["--t-pri"]}`:"none",
                paddingBottom:2 }}>{t}</span>
            ))}
          </div>
          <div style={{ background:temaVis.vars["--t-bg"],padding:"6px 14px 10px" }}>
            <div style={{ background:temaVis.vars["--t-card"],borderRadius:10,padding:"8px 10px",
                          border:`1px solid ${temaVis.vars["--t-bor"]}` }}>
              <div style={{ display:"flex",justifyContent:"space-between",alignItems:"center" }}>
                <span style={{ fontSize:12,fontWeight:700,color:temaVis.vars["--t-txt"],
                               fontFamily:temaVis.vars["--t-font"] }}>João Silva</span>
                <span style={{ fontSize:10,fontWeight:800,color:"#f97316",
                               background:"#f9730022",padding:"2px 7px",borderRadius:10 }}>HOJE</span>
              </div>
            </div>
            <div style={{ marginTop:8,textAlign:"center" }}>
              <div style={{ display:"inline-flex",alignItems:"center",justifyContent:"center",
                            width:36,height:36,borderRadius:"50%",
                            background:temaVis.vars["--t-fab"] }}>
                <Ic n="plus" sz={18} col="#fff"/>
              </div>
            </div>
          </div>
        </div>

        {/* Grid de temas */}
        <div style={{ padding:"12px 18px 28px",display:"grid",gridTemplateColumns:"1fr 1fr",gap:8 }}>
          {TEMAS.map(t=>{
            const isAtivo = t.id===ativo;
            return (
              <button key={t.id}
                onClick={()=>aplicar(t)}
                onMouseEnter={()=>setHover(t.id)} onMouseLeave={()=>setHover(null)}
                onTouchStart={()=>setHover(t.id)} onTouchEnd={()=>setHover(null)}
                style={{
                  background:t.vars["--t-card"],
                  border:`${isAtivo?"2.5px solid":"1.5px solid"} ${t.vars["--t-pri"]}${isAtivo?"":"55"}`,
                  borderRadius:13,padding:"12px 10px",cursor:"pointer",textAlign:"left",
                  position:"relative",
                  transform:isAtivo?"scale(1.03)":"scale(1)",transition:"all .2s",
                }}>
                {isAtivo&&(
                  <div style={{ position:"absolute",top:7,right:7,width:17,height:17,borderRadius:"50%",
                                background:t.vars["--t-pri"],display:"flex",alignItems:"center",
                                justifyContent:"center" }}>
                    <Ic n="check" sz={9} col="#fff"/>
                  </div>
                )}
                {/* Emoji + swatches */}
                <div style={{ fontSize:24,marginBottom:6 }}>{t.emoji}</div>
                <div style={{ display:"flex",gap:4,marginBottom:6 }}>
                  {t.preview.map((c,i)=>(
                    <div key={i} style={{ width:14,height:14,borderRadius:"50%",background:c,
                                          border:"1px solid rgba(0,0,0,.1)" }}/>
                  ))}
                </div>
                <div style={{ fontSize:12,fontWeight:800,color:t.vars["--t-txt"],
                              fontFamily:t.vars["--t-font"],lineHeight:1.2 }}>{t.nome}</div>
                <div style={{ fontSize:10,color:t.vars["--t-txt2"],marginTop:2 }}>{t.desc}</div>
                <div style={{ marginTop:9,padding:"4px 0",background:t.vars["--t-pri"],
                              borderRadius:t.vars["--t-r"]||"8px",textAlign:"center",
                              fontSize:10,fontWeight:900,color:"#fff",
                              fontFamily:t.vars["--t-font"] }}>ATIVAR</div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════
//  PAINEL IMPORTAÇÃO
// ═══════════════════════════════════════
// ═══════════════════════════════════════
//  ABA NUVEM ☁️ — Sync inteligente
// ═══════════════════════════════════════
function AbaNuvem({ analise, syncSt, lastSync, totalLocal, onImportar, onSyncNow }) {
  const [modo,    setModo]    = useState(()=>lsGet(SYNC_MODE_KEY)||"manual");
  const [sel,     setSel]     = useState({});
  const [loading, setLoading] = useState(false);

  const todos = [...(analise?.novos||[]), ...(analise?.atualizados||[])];
  const dups  = analise?.duplicados || [];
  const pendentes = todos.length;

  const toggleModo = m => { setModo(m); lsSet(SYNC_MODE_KEY, m); };
  const toggle  = id => setSel(p=>({...p,[id]:!p[id]}));
  const selAll  = () => { const s={}; todos.forEach(c=>{ s[c._cloudId]=true; }); setSel(s); };
  const selNone = () => setSel({});
  const selecionados = todos.filter(c=>sel[c._cloudId]);

  const importarTudo = async () => { setLoading(true); await onImportar(todos); setLoading(false); };
  const importarSel  = async () => {
    if(!selecionados.length) return;
    setLoading(true); await onImportar(selecionados); setSel({}); setLoading(false);
  };
  const importarUm = async (c) => { setLoading(true); await onImportar([c]); setLoading(false); };

  const syncIcon = syncSt==="syncing"?"🔄":syncSt==="erro"?"❌":"☁️";
  const syncCor  = syncSt==="erro"?"#ef4444":syncSt==="syncing"?"#f97316":"#16a34a";
  const initials = nome => (nome||"?").split(" ").slice(0,2).map(w=>w[0]).join("").toUpperCase();

  return (
    <div style={{ padding:"12px 12px 100px" }}>

      {/* ── Card status */}
      <div style={{ background:"var(--t-card,#fff)",borderRadius:16,padding:"16px",
                    marginBottom:12,border:"1px solid var(--t-bor,#e5e7eb)",
                    boxShadow:"0 1px 6px rgba(0,0,0,.06)" }}>
        <div style={{ display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:14 }}>
          <div style={{ display:"flex",alignItems:"center",gap:12 }}>
            <div style={{ width:48,height:48,borderRadius:14,background:syncCor+"18",
                          display:"flex",alignItems:"center",justifyContent:"center",fontSize:26 }}>
              {syncIcon}
            </div>
            <div>
              <p style={{ margin:0,fontSize:15,fontWeight:800,color:"var(--t-txt,#111)" }}>
                {syncSt==="syncing"?"Sincronizando...":syncSt==="erro"?"Erro de conexão":"Sincronização Ativa"}
              </p>
              <p style={{ margin:"2px 0 0",fontSize:11,color:syncSt==="erro"?"#ef4444":"var(--t-txt2,#888)" }}>
                {syncSt==="erro"?"Verifique sua conexão":lastSync?`Última sync: ${lastSync.getHours().toString().padStart(2,"0")}:${lastSync.getMinutes().toString().padStart(2,"0")}`:"Aguardando sync..."}
              </p>
            </div>
          </div>
          <button onClick={onSyncNow}
            style={{ padding:"8px 14px",borderRadius:10,border:"none",cursor:"pointer",
                     background:"var(--t-pri,#16a34a)15",color:"var(--t-pri,#16a34a)",
                     fontSize:12,fontWeight:800,display:"flex",alignItems:"center",gap:5 }}>
            <Ic n="refresh" sz={13} col="var(--t-pri,#16a34a)"/> ATUALIZAR
          </button>
        </div>
        <div style={{ display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:8 }}>
          {[
            { label:"LOCAL",     val:totalLocal,              cor:"var(--t-txt,#555)", bg:"#f8f9fa" },
            { label:"NUVEM",     val:analise?.totalNuvem||0,  cor:"#2563eb",            bg:"#eff6ff" },
            { label:"PENDENTES", val:pendentes,               cor:"var(--t-pri,#16a34a)",bg:"#f0fdf4" },
          ].map(({label,val,cor,bg})=>(
            <div key={label} style={{ background:bg,borderRadius:10,padding:"10px 8px",
                                       textAlign:"center",border:"1px solid #e9ecef" }}>
              <p style={{ margin:"0 0 3px",fontSize:9,color:"#888",fontWeight:700,letterSpacing:.5 }}>{label}</p>
              <p style={{ margin:0,fontSize:22,fontWeight:900,color:cor }}>{val}</p>
            </div>
          ))}
        </div>
      </div>

      {/* ── Modo de sync */}
      <div style={{ background:"var(--t-card,#fff)",borderRadius:16,padding:"14px 16px",
                    marginBottom:12,border:"1px solid var(--t-bor,#e5e7eb)" }}>
        <p style={{ margin:"0 0 10px",fontSize:13,fontWeight:800,color:"var(--t-txt,#111)" }}>⚙️ Modo de Importação</p>
        <div style={{ display:"flex",gap:8 }}>
          {[
            { id:"auto",   emoji:"⚡", title:"Automático", desc:"Importa novos contatos sem perguntar" },
            { id:"manual", emoji:"👆", title:"Manual",     desc:"Você decide o que importar da nuvem" },
          ].map(m=>(
            <button key={m.id} onClick={()=>toggleModo(m.id)}
              style={{ flex:1,padding:"12px 10px",borderRadius:12,textAlign:"left",cursor:"pointer",
                       border:`2px solid ${modo===m.id?"var(--t-pri,#16a34a)":"#e5e7eb"}`,
                       background:modo===m.id?"var(--t-pri,#16a34a)08":"#fafafa",transition:"all .15s" }}>
              <div style={{ fontSize:18,marginBottom:4 }}>{m.emoji}</div>
              <p style={{ margin:"0 0 2px",fontSize:12,fontWeight:800,
                          color:modo===m.id?"var(--t-pri,#16a34a)":"#333" }}>{m.title}</p>
              <p style={{ margin:0,fontSize:9,color:"#888",lineHeight:1.4 }}>{m.desc}</p>
              {modo===m.id&&(
                <div style={{ marginTop:5,display:"flex",alignItems:"center",gap:3,
                              color:"var(--t-pri,#16a34a)",fontSize:10,fontWeight:700 }}>
                  <Ic n="check" sz={10} col="var(--t-pri,#16a34a)"/> Ativo
                </div>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* ── Pendentes */}
      {todos.length > 0 && (
        <div style={{ background:"var(--t-card,#fff)",borderRadius:16,padding:"14px 16px",
                      marginBottom:12,border:"1px solid var(--t-bor,#e5e7eb)" }}>
          <div style={{ display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:12 }}>
            <p style={{ margin:0,fontSize:13,fontWeight:800,color:"var(--t-txt,#111)" }}>
              📥 Clientes Pendentes ({todos.length})
            </p>
            <div style={{ display:"flex",gap:6,alignItems:"center" }}>
              {modo==="manual"&&(
                <>
                  <button onClick={selAll} style={{ fontSize:11,color:"var(--t-pri,#16a34a)",background:"none",border:"none",cursor:"pointer",fontWeight:700 }}>Todos</button>
                  <span style={{ color:"#ddd" }}>|</span>
                  <button onClick={selNone} style={{ fontSize:11,color:"#aaa",background:"none",border:"none",cursor:"pointer" }}>Nenhum</button>
                </>
              )}
              <button onClick={importarTudo} disabled={loading}
                style={{ fontSize:11,fontWeight:800,color:"#fff",
                         background:"var(--t-pri,#16a34a)",border:"none",
                         borderRadius:7,padding:"4px 10px",cursor:"pointer" }}>
                {loading?"...":"Importar Tudo"}
              </button>
            </div>
          </div>

          <div style={{ display:"flex",flexDirection:"column",gap:8 }}>
            {todos.map(c=>{
              const isNovo = (analise?.novos||[]).some(x=>x._cloudId===c._cloudId);
              const cor    = isNovo?"#16a34a":"#2563eb";
              const label  = isNovo?"NOVO":"ATUALIZ.";
              const isChk  = modo==="auto" ? true : !!sel[c._cloudId];
              const telN   = (c.tel||"").replace(/\D/g,"");
              const vencC  = calcVenc(c.dataVenc);
              const corV   = VC[vencC]||"#22c55e";
              return (
                <div key={c._cloudId}
                  style={{ borderRadius:14,border:`1.5px solid ${isChk?cor+"44":"#e5e7eb"}`,
                           background:"var(--t-card,#fff)",overflow:"hidden",transition:"all .15s",
                           boxShadow:"0 1px 4px rgba(0,0,0,.04)" }}>
                  <div style={{ height:3,background:corV+"88" }}/>
                  <div style={{ display:"flex",alignItems:"flex-start",gap:10,padding:"11px 12px" }}>
                    <div style={{ width:36,height:36,borderRadius:10,background:cor+"20",flexShrink:0,
                                  display:"flex",alignItems:"center",justifyContent:"center",
                                  fontSize:13,fontWeight:800,color:cor }}>
                      {initials(c.nome)}
                    </div>
                    <div style={{ flex:1,minWidth:0 }}>
                      <div style={{ display:"flex",alignItems:"center",gap:6,marginBottom:3,flexWrap:"wrap" }}>
                        <span style={{ fontSize:14,fontWeight:800,color:"var(--t-txt,#111)",
                                       overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap" }}>{c.nome}</span>
                        <span style={{ fontSize:9,fontWeight:800,color:cor,background:cor+"18",
                                       padding:"2px 7px",borderRadius:10,border:`1px solid ${cor}33`,flexShrink:0 }}>{label}</span>
                        <BadgeVenc dataVenc={c.dataVenc} size={9}/>
                      </div>
                      <div style={{ display:"grid",gridTemplateColumns:"1fr 1fr",gap:"2px 8px" }}>
                        {c.usuario&&<p style={{ margin:0,fontSize:11,color:"var(--t-txt2,#888)" }}><span style={{ color:"#aaa" }}>👤 </span>{c.usuario}</p>}
                        {telN.length>=10&&<p style={{ margin:0,fontSize:11,color:"var(--t-txt2,#888)" }}><span style={{ color:"#aaa" }}>📱 </span>{fmtTel(telN)}</p>}
                        {c.dataVenc&&<p style={{ margin:0,fontSize:11,color:corV,fontWeight:700 }}><span style={{ color:"#aaa",fontWeight:400 }}>📅 </span>{fmtDate(c.dataVenc)}</p>}
                        {c.plano&&<p style={{ margin:0,fontSize:11,color:"var(--t-txt2,#888)" }}><span style={{ color:"#aaa" }}>📦 </span>{c.plano}</p>}
                        {c.valor&&<p style={{ margin:0,fontSize:11,color:"#16a34a",fontWeight:700 }}><span style={{ color:"#aaa",fontWeight:400 }}>💰 </span>{fmtBRL(c.valor)}</p>}
                      </div>
                    </div>
                    <div style={{ display:"flex",flexDirection:"column",alignItems:"center",gap:6,flexShrink:0 }}>
                      {modo==="manual"&&(
                        <div onClick={()=>toggle(c._cloudId)}
                          style={{ width:22,height:22,borderRadius:6,cursor:"pointer",
                                   border:`2px solid ${isChk?cor:"#ddd"}`,background:isChk?cor:"#fff",
                                   display:"flex",alignItems:"center",justifyContent:"center" }}>
                          {isChk&&<Ic n="check" sz={11} col="#fff"/>}
                        </div>
                      )}
                      <button onClick={()=>importarUm(c)} disabled={loading}
                        style={{ width:32,height:32,borderRadius:9,border:"none",background:cor,
                                 cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",
                                 boxShadow:`0 2px 6px ${cor}44` }}>
                        <Ic n="download" sz={14} col="#fff"/>
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {modo==="manual"&&(
            <div style={{ marginTop:12,display:"grid",gridTemplateColumns:"2fr 1fr",gap:8 }}>
              <button onClick={importarSel} disabled={loading||selecionados.length===0}
                style={{ padding:"13px 0",borderRadius:11,border:"none",
                         background:selecionados.length===0||loading?"#e5e7eb":"var(--t-pri,#16a34a)",
                         color:selecionados.length===0||loading?"#aaa":"#fff",
                         fontSize:13,fontWeight:800,
                         cursor:selecionados.length>0&&!loading?"pointer":"not-allowed",
                         display:"flex",alignItems:"center",justifyContent:"center",gap:7,
                         boxShadow:selecionados.length>0?"0 3px 12px rgba(22,163,74,.3)":"none" }}>
                <Ic n="download" sz={16} col={selecionados.length>0?"#fff":"#aaa"}/>
                {loading?"Importando...":selecionados.length>0?`Importar selecionados (${selecionados.length})`:"Selecione clientes"}
              </button>
              <button onClick={importarTudo} disabled={loading}
                style={{ padding:"13px 0",borderRadius:11,
                         border:"1.5px solid var(--t-pri,#16a34a)",background:"transparent",
                         color:"var(--t-pri,#16a34a)",fontSize:13,fontWeight:800,cursor:"pointer",
                         display:"flex",alignItems:"center",justifyContent:"center",gap:5 }}>
                Todos ({todos.length})
              </button>
            </div>
          )}
        </div>
      )}

      {/* ── Já sincronizados */}
      {dups.length > 0 && (
        <div style={{ background:"var(--t-card,#fff)",borderRadius:16,padding:"14px 16px",
                      marginBottom:12,border:"1px solid var(--t-bor,#e5e7eb)" }}>
          <p style={{ margin:"0 0 10px",fontSize:12,fontWeight:800,color:"var(--t-txt2,#888)",
                      textTransform:"uppercase",letterSpacing:.5 }}>
            ✅ Já Sincronizados
          </p>
          {dups.slice(0,5).map(c=>(
            <div key={c._cloudId} style={{ display:"flex",alignItems:"center",gap:10,
                                            padding:"8px 0",borderBottom:"1px dashed #f0f0f0" }}>
              <div style={{ width:32,height:32,borderRadius:8,flexShrink:0,background:"#f0f0f0",
                            display:"flex",alignItems:"center",justifyContent:"center",
                            fontSize:11,fontWeight:700,color:"#888" }}>
                {initials(c.nome)}
              </div>
              <div style={{ flex:1,minWidth:0 }}>
                <p style={{ margin:0,fontSize:12,fontWeight:700,color:"var(--t-txt2,#999)",
                             overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap" }}>{c.nome}</p>
                <p style={{ margin:0,fontSize:10,color:"#aaa" }}>Sincronizado</p>
              </div>
              <svg width="18" height="18" viewBox="0 0 20 20" fill="#22c55e">
                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd"/>
              </svg>
            </div>
          ))}
          {dups.length>5&&<p style={{ margin:"8px 0 0",fontSize:11,color:"#ccc",textAlign:"center" }}>+{dups.length-5} mais...</p>}
        </div>
      )}

      {/* ── Vazio */}
      {todos.length===0&&dups.length===0&&(
        <div style={{ textAlign:"center",padding:"50px 20px",color:"#aaa" }}>
          <div style={{ fontSize:56,marginBottom:12 }}>☁️</div>
          <p style={{ margin:0,fontSize:15,fontWeight:700,color:"var(--t-txt,#555)" }}>Tudo sincronizado!</p>
          <p style={{ margin:"6px 0 0",fontSize:13 }}>Nenhum cliente novo na nuvem</p>
        </div>
      )}
    </div>
  );
}

// Painel modal (para o banner da home)
function PainelImport({ analise, onImportar, onFechar }) {
  const todos = [...(analise?.novos||[]), ...(analise?.atualizados||[])];
  const [sel, setSel] = useState(()=>{
    const s={}; todos.forEach(c=>{ s[c._cloudId]=true; }); return s;
  });
  const toggle = id => setSel(p=>({...p,[id]:!p[id]}));
  const sel$ = todos.filter(c=>sel[c._cloudId]);
  if(!analise) return null;

  return (
    <div style={{ position:"fixed",inset:0,zIndex:800,background:"rgba(0,0,0,.7)",
                  display:"flex",alignItems:"flex-end" }}
         onClick={e=>e.target===e.currentTarget&&onFechar()}>
      <div style={{ width:"100%",maxWidth:440,margin:"0 auto",background:"var(--t-card,#fff)",
                    borderRadius:"20px 20px 0 0",maxHeight:"86vh",overflowY:"auto" }}>
        <div style={{ display:"flex",justifyContent:"center",padding:"10px 0 4px" }}>
          <div style={{ width:36,height:4,borderRadius:2,background:"#e5e7eb" }}/>
        </div>
        <div style={{ padding:"8px 18px 10px",display:"flex",alignItems:"center",
                      justifyContent:"space-between",borderBottom:"1px solid #f0f0f0" }}>
          <div>
            <p style={{ margin:0,fontSize:16,fontWeight:800,color:"var(--t-txt,#111)" }}>
              ☁️ {todos.length} novo{todos.length!==1?"s":""} na nuvem
            </p>
            <p style={{ margin:"2px 0 0",fontSize:11,color:"#888" }}>
              Selecione para importar para o local
            </p>
          </div>
          <button onClick={onFechar} style={{ background:"#f3f4f6",border:"none",
            borderRadius:"50%",width:32,height:32,cursor:"pointer",
            display:"flex",alignItems:"center",justifyContent:"center" }}>
            <Ic n="close" sz={14} col="#666"/>
          </button>
        </div>
        <div style={{ padding:"10px 16px 24px",display:"flex",flexDirection:"column",gap:7 }}>
          {todos.map(c=>{
            const isNovo=(analise?.novos||[]).some(x=>x._cloudId===c._cloudId);
            const cor=isNovo?"#16a34a":"#2563eb";
            const isChk=!!sel[c._cloudId];
            return(
              <div key={c._cloudId} onClick={()=>toggle(c._cloudId)}
                style={{ display:"flex",alignItems:"center",gap:10,padding:"10px 12px",
                         borderRadius:11,border:`1.5px solid ${isChk?cor+"55":"#e5e7eb"}`,
                         background:isChk?cor+"08":"#fafafa",cursor:"pointer" }}>
                <div style={{ width:22,height:22,borderRadius:6,flexShrink:0,
                              border:`2px solid ${isChk?cor:"#ddd"}`,background:isChk?cor:"#fff",
                              display:"flex",alignItems:"center",justifyContent:"center" }}>
                  {isChk&&<Ic n="check" sz={11} col="#fff"/>}
                </div>
                <div style={{ flex:1,minWidth:0 }}>
                  <div style={{ display:"flex",alignItems:"center",gap:6 }}>
                    <span style={{ fontSize:13,fontWeight:700,color:"var(--t-txt,#111)" }}>{c.nome}</span>
                    <span style={{ fontSize:10,fontWeight:800,color:cor,background:cor+"18",
                                   padding:"1px 6px",borderRadius:10 }}>{isNovo?"NOVO":"ATUALIZ."}</span>
                    <BadgeVenc dataVenc={c.dataVenc} size={10}/>
                  </div>
                  <p style={{ margin:"2px 0 0",fontSize:11,color:"#888" }}>
                    {c.usuario&&`@${c.usuario} • `}{fmtDate(c.dataVenc)}{c.plano&&` • ${c.plano}`}
                  </p>
                </div>
              </div>
            );
          })}
          <div style={{ display:"flex",gap:8,marginTop:4 }}>
            <button onClick={()=>onImportar(sel$)} disabled={sel$.length===0}
              style={{ flex:2,padding:"13px 0",borderRadius:11,border:"none",
                       background:sel$.length>0?"linear-gradient(135deg,#16a34a,#15803d)":"#e5e7eb",
                       color:sel$.length>0?"#fff":"#aaa",fontSize:14,fontWeight:800,
                       cursor:sel$.length>0?"pointer":"not-allowed",
                       display:"flex",alignItems:"center",justifyContent:"center",gap:7 }}>
              <Ic n="download" sz={16} col={sel$.length>0?"#fff":"#aaa"}/>
              Importar {sel$.length>0?`(${sel$.length})`:""}
            </button>
            <button onClick={()=>onImportar(todos)}
              style={{ flex:1,padding:"13px 0",borderRadius:11,border:"1.5px solid #e5e7eb",
                       background:"#f8f9fa",color:"#555",fontSize:12,fontWeight:700,
                       cursor:"pointer",display:"flex",alignItems:"center",
                       justifyContent:"center",gap:5 }}>
              Todos
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════
//  MODAL CLIENTE — 3 etapas
// ═══════════════════════════════════════
const PLANOS = ["Mensal","Trimestral","Semestral","Anual","Avulso"];
const PLANOS_DIAS = { Mensal:30, Trimestral:90, Semestral:180, Anual:365, Avulso:0 };

function ModalCliente({ clienteEdit, onSalvar, onFechar }) {
  const isEdit = !!clienteEdit;
  const [step, setStep] = useState(0);
  const [dados, setDados] = useState(() => ({
    nome:    clienteEdit?.nome    || "",
    usuario: clienteEdit?.usuario || "",
    tel:     clienteEdit?.tel     || "",
    plano:   clienteEdit?.plano   || "Mensal",
    valor:   clienteEdit?.valor   || "",
    dataVenc:clienteEdit?.dataVenc|| "",
    obs:     clienteEdit?.obs     || "",
  }));

  const set = (k,v) => setDados(p=>({...p,[k]:v}));

  // Calcula data de vencimento a partir do plano
  const calcDataPlano = plano => {
    const dias = PLANOS_DIAS[plano] || 0;
    if (!dias) return "";
    const d = new Date(); d.setDate(d.getDate()+dias);
    return d.toISOString().split("T")[0];
  };

  const ok0 = dados.nome.trim().length > 0;
  const ok1 = dados.plano && dados.dataVenc;

  return (
    <div style={{ position:"fixed",inset:0,zIndex:700,background:"rgba(0,0,0,.7)",
                  display:"flex",alignItems:"flex-end" }}
         onClick={e=>e.target===e.currentTarget&&onFechar()}>
      <div style={{ width:"100%",maxWidth:440,margin:"0 auto",background:"#fff",
                    borderRadius:"20px 20px 0 0",maxHeight:"90vh",overflowY:"auto" }}>
        {/* Handle */}
        <div style={{ display:"flex",justifyContent:"center",padding:"10px 0 4px" }}>
          <div style={{ width:36,height:4,borderRadius:2,background:"#e5e7eb" }}/>
        </div>
        {/* Header */}
        <div style={{ padding:"8px 18px 12px",display:"flex",alignItems:"center",
                      justifyContent:"space-between",borderBottom:"1px solid #f0f0f0" }}>
          <div style={{ display:"flex",alignItems:"center",gap:10 }}>
            {step>0&&(
              <button onClick={()=>setStep(s=>s-1)} style={{ background:"none",border:"none",
                cursor:"pointer",padding:4,display:"flex",alignItems:"center" }}>
                <Ic n="back" sz={18} col="#666"/>
              </button>
            )}
            <p style={{ margin:0,fontSize:17,fontWeight:800,color:"#111" }}>
              {isEdit?"Editar":"Novo"} Cliente {["·nome","·plano","·obs"][step]}
            </p>
          </div>
          <div style={{ display:"flex",alignItems:"center",gap:8 }}>
            <span style={{ fontSize:12,color:"#aaa" }}>{step+1}/3</span>
            <button onClick={onFechar} style={{ background:"#f3f4f6",border:"none",
              borderRadius:"50%",width:32,height:32,cursor:"pointer",
              display:"flex",alignItems:"center",justifyContent:"center" }}>
              <Ic n="close" sz={14} col="#666"/>
            </button>
          </div>
        </div>

        <div style={{ padding:"16px 18px 28px" }}>
          {/* ETAPA 0: Nome, usuário, telefone, valor */}
          {step===0&&(
            <div style={{ display:"flex",flexDirection:"column",gap:12 }}>
              {[
                { k:"nome",    label:"👤 Nome",     ph:"Nome completo", required:true },
                { k:"usuario", label:"🔑 Usuário",  ph:"Login / @usuario" },
                { k:"tel",     label:"📱 Telefone", ph:"(11) 99999-8888" },
                { k:"valor",   label:"💰 Valor",    ph:"R$ 20,00" },
              ].map(({k,label,ph,required})=>(
                <div key={k}>
                  <label style={{ fontSize:12,fontWeight:700,color:"#555",display:"block",marginBottom:5 }}>
                    {label}{required&&<span style={{ color:"#ef4444" }}>*</span>}
                  </label>
                  <input value={dados[k]} onChange={e=>set(k,e.target.value)}
                    placeholder={ph}
                    style={{ width:"100%",boxSizing:"border-box",border:"1.5px solid #e5e7eb",
                             borderRadius:10,padding:"11px 13px",fontSize:14,color:"#222",
                             outline:"none",background:"#fafafa" }}/>
                </div>
              ))}
              <button onClick={()=>setStep(1)} disabled={!ok0}
                style={{ marginTop:4,padding:"13px 0",borderRadius:12,border:"none",
                         background:ok0?"var(--t-pri,#16a34a)":"#e5e7eb",
                         color:ok0?"#fff":"#aaa",fontSize:14,fontWeight:800,cursor:ok0?"pointer":"not-allowed" }}>
                Próximo →
              </button>
            </div>
          )}

          {/* ETAPA 1: Plano + data */}
          {step===1&&(
            <div style={{ display:"flex",flexDirection:"column",gap:12 }}>
              <div>
                <label style={{ fontSize:12,fontWeight:700,color:"#555",display:"block",marginBottom:8 }}>
                  📦 Plano
                </label>
                <div style={{ display:"flex",flexWrap:"wrap",gap:7 }}>
                  {PLANOS.map(p=>(
                    <button key={p} onClick={()=>{ set("plano",p); if(PLANOS_DIAS[p]) set("dataVenc",calcDataPlano(p)); }}
                      style={{ padding:"9px 16px",borderRadius:20,border:"none",
                               background:dados.plano===p?"var(--t-pri,#16a34a)":"#f3f4f6",
                               color:dados.plano===p?"#fff":"#555",
                               fontSize:13,fontWeight:700,cursor:"pointer" }}>
                      {p}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <label style={{ fontSize:12,fontWeight:700,color:"#555",display:"block",marginBottom:5 }}>
                  📅 Data de Vencimento
                </label>
                <input type="date" value={dados.dataVenc} onChange={e=>set("dataVenc",e.target.value)}
                  style={{ width:"100%",boxSizing:"border-box",border:"1.5px solid #e5e7eb",
                           borderRadius:10,padding:"11px 13px",fontSize:14,color:"#222",
                           outline:"none",background:"#fafafa" }}/>
                {dados.dataVenc&&(
                  <div style={{ marginTop:6,display:"flex",alignItems:"center",gap:6 }}>
                    <BadgeVenc dataVenc={dados.dataVenc}/>
                    <span style={{ fontSize:12,color:"#888" }}>
                      {diffDias(dados.dataVenc)!==null&&diffDias(dados.dataVenc)>=0
                        ?`Vence em ${diffDias(dados.dataVenc)} dia${diffDias(dados.dataVenc)===1?"":"s"}`
                        :`${Math.abs(diffDias(dados.dataVenc))} dia${Math.abs(diffDias(dados.dataVenc))===1?"":"s"} em atraso`}
                    </span>
                  </div>
                )}
              </div>
              <button onClick={()=>setStep(2)} disabled={!ok1}
                style={{ marginTop:4,padding:"13px 0",borderRadius:12,border:"none",
                         background:ok1?"var(--t-pri,#16a34a)":"#e5e7eb",
                         color:ok1?"#fff":"#aaa",fontSize:14,fontWeight:800,cursor:ok1?"pointer":"not-allowed" }}>
                Próximo →
              </button>
            </div>
          )}

          {/* ETAPA 2: Obs + salvar */}
          {step===2&&(
            <div style={{ display:"flex",flexDirection:"column",gap:12 }}>
              {/* Preview */}
              <div style={{ background:"#f8f9fa",borderRadius:12,padding:"12px 14px",
                            border:"1px solid #e9ecef" }}>
                <div style={{ display:"flex",justifyContent:"space-between",alignItems:"flex-start" }}>
                  <div>
                    <p style={{ margin:"0 0 2px",fontSize:15,fontWeight:800,color:"#111" }}>{dados.nome}</p>
                    <p style={{ margin:0,fontSize:12,color:"#888" }}>
                      {dados.usuario&&`@${dados.usuario} • `}
                      {fmtDate(dados.dataVenc)&&`${fmtDate(dados.dataVenc)} • `}
                      {dados.plano}{dados.valor&&` • ${fmtBRL(dados.valor)}`}
                    </p>
                  </div>
                  <BadgeVenc dataVenc={dados.dataVenc}/>
                </div>
              </div>
              <div>
                <label style={{ fontSize:12,fontWeight:700,color:"#555",display:"block",marginBottom:5 }}>
                  📝 Observação (opcional)
                </label>
                {/* Tags rápidas */}
                <div style={{ display:"flex",flexWrap:"wrap",gap:5,marginBottom:8 }}>
                  {["VIP","Paga adiantado","Reagendou","Inadimplente","Indicação"].map(tag=>(
                    <button key={tag} onClick={()=>set("obs",tag)}
                      style={{ padding:"4px 10px",borderRadius:16,border:"1.5px solid #e5e7eb",
                               background:dados.obs===tag?"var(--t-pri,#16a34a)":"#f8f9fa",
                               color:dados.obs===tag?"#fff":"#555",
                               fontSize:12,fontWeight:600,cursor:"pointer" }}>
                      {tag}
                    </button>
                  ))}
                </div>
                <textarea value={dados.obs} onChange={e=>set("obs",e.target.value)}
                  placeholder="Notas sobre o cliente..." rows={3}
                  style={{ width:"100%",boxSizing:"border-box",border:"1.5px solid #e5e7eb",
                           borderRadius:10,padding:"10px 12px",fontSize:13,fontFamily:"inherit",
                           color:"#222",resize:"none",background:"#fafafa",outline:"none" }}/>
              </div>
              <button onClick={()=>onSalvar(dados)}
                style={{ padding:"14px 0",borderRadius:12,border:"none",
                         background:"var(--t-pri,#16a34a)",color:"#fff",
                         fontSize:14,fontWeight:800,cursor:"pointer",
                         display:"flex",alignItems:"center",justifyContent:"center",gap:8,
                         boxShadow:"0 3px 14px rgba(22,163,74,.35)" }}>
                <Ic n="check" sz={17} col="#fff"/>
                {isEdit?"Salvar alterações":"Adicionar Cliente"}
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════
//  CARD CLIENTE
// ═══════════════════════════════════════
function CardCliente({ c, onEdit, onDelete }) {
  const venc   = calcVenc(c.dataVenc);
  const cor    = VC[venc] || "#22c55e";
  const tel    = (c.tel||"").replace(/\D/g,"");


  return (
    <div style={{ background:"var(--t-card,#fff)",borderRadius:14,marginBottom:10,
                  boxShadow:"0 1px 6px rgba(0,0,0,.06)",border:"1px solid var(--t-bor,#e5e7eb)",
                  overflow:"hidden" }}>
      {/* Linha de urgência no topo */}
      <div style={{ height:3,background:cor+"66" }}/>

      <div style={{ padding:"11px 13px 11px" }}>
        {/* Linha 1: dot + nome + badge */}
        <div style={{ display:"flex",alignItems:"center",gap:8 }}>
          <div style={{ width:10,height:10,borderRadius:"50%",background:cor,flexShrink:0 }}/>
          <div style={{ flex:1,minWidth:0 }}>
            <span style={{ fontSize:15,fontWeight:800,color:"var(--t-txt,#111)",
                           fontFamily:"var(--t-font,inherit)" }}>
              {c.nome}
            </span>
            {c.usuario&&(
              <span style={{ fontSize:12,color:"#999",marginLeft:5 }}>({c.usuario})</span>
            )}
          </div>
          <BadgeVenc dataVenc={c.dataVenc}/>
        </div>

        {/* Grid de info */}
        <div style={{ margin:"6px 0 4px 18px",display:"grid",
                      gridTemplateColumns:"1fr 1fr",gap:"3px 10px" }}>
          {c.usuario&&(
            <p style={{ margin:0,fontSize:12,color:"var(--t-txt2,#888)" }}>
              👤 <b style={{ color:"var(--t-txt,#333)" }}>{c.usuario}</b>
            </p>
          )}
          {tel.length>=10&&(
            <p style={{ margin:0,fontSize:12,color:"var(--t-txt2,#888)" }}>
              📱 {fmtTel(tel)}
            </p>
          )}
          {c.dataVenc&&(
            <p style={{ margin:0,fontSize:12,color:cor,fontWeight:700 }}>
              📅 {fmtDate(c.dataVenc)}
            </p>
          )}
          {c.plano&&(
            <p style={{ margin:0,fontSize:12,color:"var(--t-txt2,#888)" }}>
              📦 {c.plano}
            </p>
          )}
          {c.valor&&(
            <p style={{ margin:0,fontSize:12,color:"#16a34a",fontWeight:700 }}>
              💰 {fmtBRL(c.valor)}
            </p>
          )}
          {c.fornecedor&&(
            <p style={{ margin:0,fontSize:11,color:"var(--t-txt2,#aaa)" }}>
              🏷 {c.fornecedor}
            </p>
          )}
        </div>

        {/* Linha 3: obs + botões */}
        <div style={{ display:"flex",alignItems:"center",justifyContent:"space-between",
                      marginLeft:18,marginTop:c.fornecedor||c.renovadoAte?0:6 }}>
          {/* Obs */}
          <span style={{ fontSize:11,color:"#aaa",flex:1,overflow:"hidden",
                         textOverflow:"ellipsis",whiteSpace:"nowrap",marginRight:8 }}>
            {c.obs||""}
          </span>

          {/* Botões de ação */}
          <div style={{ display:"flex",gap:6,flexShrink:0 }}>
            {/* WhatsApp Cobrar */}
            {tel.length>=10&&(
              <button onClick={()=>abrirWhatsApp(c)}
                style={{ height:34,borderRadius:10,border:"none",cursor:"pointer",
                         background:wppCor(venc),paddingLeft:10,paddingRight:10,
                         display:"flex",alignItems:"center",justifyContent:"center",gap:5,
                         animation:(venc==="vencido"||venc==="hoje")?"wppPulse 2s infinite":"none",
                         boxShadow:`0 2px 8px ${wppCor(venc)}55` }}>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="white">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347z"/>
                  <path d="M12 0C5.373 0 0 5.373 0 12c0 2.115.554 4.101 1.523 5.824L.057 23.737a.5.5 0 00.614.63l6.01-1.457A11.945 11.945 0 0012 24c6.627 0 12-5.373 12-12S18.627 0 12 0zm0 22c-1.89 0-3.663-.524-5.174-1.433l-.37-.22-3.565.864.912-3.477-.242-.382A9.944 9.944 0 012 12C2 6.477 6.477 2 12 2s10 4.477 10 10-4.477 10-10 10z"/>
                </svg>
                <span style={{ fontSize:11,fontWeight:700,color:"#fff" }}>Cobrar</span>
              </button>
            )}
            {/* Editar */}
            <button onClick={()=>onEdit(c)}
              style={{ width:34,height:34,borderRadius:"50%",border:"none",cursor:"pointer",
                       background:"var(--t-pri,#16a34a)18",
                       display:"flex",alignItems:"center",justifyContent:"center" }}>
              <Ic n="edit" sz={14} col="var(--t-pri,#16a34a)"/>
            </button>
            {/* Deletar */}
            <button onClick={()=>onDelete(c._id)}
              style={{ width:34,height:34,borderRadius:"50%",border:"none",cursor:"pointer",
                       background:"#ef444418",
                       display:"flex",alignItems:"center",justifyContent:"center" }}>
              <Ic n="trash" sz={14} col="#ef4444"/>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════
//  ABA RESUMO
// ═══════════════════════════════════════
function AbaResumo({ arr }) {
  const pags = lsGet(PAG_KEY) || {};
  const hoje = todayISO();

  const stats = arr.reduce((acc,c)=>{
    const v = calcVenc(c.dataVenc);
    const pago = pags[c._id];
    const mes  = (c.dataVenc||"").slice(0,7);
    if (pago) acc.pagos++;
    else if (v==="vencido") acc.atrasados++;
    else if (v==="hoje")    acc.hoje++;
    else                    acc.pendentes++;
    // financeiro
    const val = parseFloat((c.valor||getValorPlano(c.plano)||"0").replace(/[^\d.,]/g,"").replace(",","."));
    if (!isNaN(val)) {
      if (pago) acc.recebido += val;
      else      acc.aReceber += val;
    }
    return acc;
  },{ pagos:0,atrasados:0,hoje:0,pendentes:0,recebido:0,aReceber:0 });

  const cards = [
    { label:"✅ Pagos",      val:stats.pagos,     cor:"#16a34a" },
    { label:"⚠️ Atrasados",  val:stats.atrasados, cor:"#ef4444" },
    { label:"🕐 Pendentes",  val:stats.pendentes, cor:"#f97316" },
    { label:"📅 Vence hoje", val:stats.hoje,      cor:"#a855f7" },
  ];

  return (
    <div style={{ padding:"14px 14px 100px" }}>
      <div style={{ display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,marginBottom:14 }}>
        {cards.map(({label,val,cor})=>(
          <div key={label} style={{ background:"var(--t-card,#fff)",borderRadius:12,padding:"14px",
                                    border:"1px solid var(--t-bor,#e5e7eb)" }}>
            <p style={{ margin:"0 0 4px",fontSize:12,color:"var(--t-txt2,#888)" }}>{label}</p>
            <p style={{ margin:0,fontSize:28,fontWeight:900,color:cor,fontFamily:"var(--t-font,inherit)" }}>{val}</p>
          </div>
        ))}
      </div>

      {/* Total financeiro */}
      <div style={{ background:"var(--t-card,#fff)",borderRadius:12,padding:"16px",
                    border:"1px solid var(--t-bor,#e5e7eb)",marginBottom:14 }}>
        <p style={{ margin:"0 0 12px",fontSize:14,fontWeight:800,color:"var(--t-txt,#111)" }}>
          💰 Financeiro do Mês
        </p>
        <div style={{ display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:8 }}>
          <span style={{ fontSize:13,color:"#888" }}>✅ Recebido</span>
          <span style={{ fontSize:16,fontWeight:800,color:"#16a34a" }}>
            R$ {stats.recebido.toFixed(2).replace(".",",")}
          </span>
        </div>
        <div style={{ height:1,background:"#f0f0f0",margin:"8px 0" }}/>
        <div style={{ display:"flex",justifyContent:"space-between",alignItems:"center" }}>
          <span style={{ fontSize:13,color:"#888" }}>⏳ A receber</span>
          <span style={{ fontSize:16,fontWeight:800,color:"#f97316" }}>
            R$ {stats.aReceber.toFixed(2).replace(".",",")}
          </span>
        </div>
        <div style={{ height:1,background:"#f0f0f0",margin:"8px 0" }}/>
        <div style={{ display:"flex",justifyContent:"space-between",alignItems:"center" }}>
          <span style={{ fontSize:14,fontWeight:800,color:"var(--t-txt,#111)" }}>Total</span>
          <span style={{ fontSize:18,fontWeight:900,color:"var(--t-pri,#16a34a)" }}>
            R$ {(stats.recebido+stats.aReceber).toFixed(2).replace(".",",")}
          </span>
        </div>
      </div>

      {/* Lista rápida urgentes */}
      {arr.filter(c=>["vencido","hoje"].includes(calcVenc(c.dataVenc))).slice(0,5).map(c=>(
        <div key={c._id} style={{ background:"var(--t-card,#fff)",borderRadius:10,padding:"10px 12px",
                                   marginBottom:7,border:"1px solid var(--t-bor,#e5e7eb)",
                                   display:"flex",justifyContent:"space-between",alignItems:"center" }}>
          <div>
            <p style={{ margin:0,fontSize:13,fontWeight:700,color:"var(--t-txt,#111)" }}>{c.nome}</p>
            <p style={{ margin:"2px 0 0",fontSize:11,color:"#888" }}>{fmtDate(c.dataVenc)}{c.plano&&` • ${c.plano}`}</p>
          </div>
          <BadgeVenc dataVenc={c.dataVenc}/>
        </div>
      ))}
    </div>
  );
}

// ═══════════════════════════════════════
//  ABA CALENDÁRIO
// ═══════════════════════════════════════
function AbaCalendario({ arr, onEdit, onDelete }) {
  const [mes, setMes] = useState(() => { const d=new Date(); return {y:d.getFullYear(),m:d.getMonth()}; });
  const pags = lsGet(PAG_KEY)||{};

  const diasNoMes = new Date(mes.y,mes.m+1,0).getDate();
  const primeiroDia = new Date(mes.y,mes.m,1).getDay();
  const mesNomes = ["Jan","Fev","Mar","Abr","Mai","Jun","Jul","Ago","Set","Out","Nov","Dez"];

  const vencMes = arr.filter(c=>{
    const iso = dmyToISO(c.dataVenc);
    return iso.startsWith(`${mes.y}-${String(mes.m+1).padStart(2,"0")}`);
  });

  const porDia = {};
  vencMes.forEach(c=>{
    const d = parseInt((dmyToISO(c.dataVenc)||"").split("-")[2]||"0");
    if (!porDia[d]) porDia[d]=[];
    porDia[d].push(c);
  });

  return (
    <div style={{ padding:"14px 14px 100px" }}>
      {/* Nav mês */}
      <div style={{ display:"flex",alignItems:"center",justifyContent:"space-between",
                    marginBottom:14,background:"var(--t-card,#fff)",borderRadius:12,
                    padding:"10px 14px",boxShadow:"0 1px 6px rgba(0,0,0,.06)" }}>
        <button onClick={()=>setMes(p=>{ const d=new Date(p.y,p.m-1); return {y:d.getFullYear(),m:d.getMonth()}; })}
          style={{ background:"none",border:"none",cursor:"pointer",fontSize:20,color:"var(--t-txt,#333)",padding:4 }}>
          ‹
        </button>
        <span style={{ fontSize:15,fontWeight:800,color:"var(--t-txt,#111)",fontFamily:"var(--t-font,inherit)" }}>
          {mesNomes[mes.m]} {mes.y} — {vencMes.length} venc.
        </span>
        <button onClick={()=>setMes(p=>{ const d=new Date(p.y,p.m+1); return {y:d.getFullYear(),m:d.getMonth()}; })}
          style={{ background:"none",border:"none",cursor:"pointer",fontSize:20,color:"var(--t-txt,#333)",padding:4 }}>
          ›
        </button>
      </div>

      {/* Grade */}
      <div style={{ display:"grid",gridTemplateColumns:"repeat(7,1fr)",gap:4,marginBottom:14 }}>
        {["D","S","T","Q","Q","S","S"].map((d,i)=>(
          <div key={i} style={{ textAlign:"center",fontSize:11,fontWeight:700,color:"#aaa",padding:"4px 0" }}>{d}</div>
        ))}
        {Array.from({length:primeiroDia}).map((_,i)=>(
          <div key={`e${i}`}/>
        ))}
        {Array.from({length:diasNoMes}).map((_,i)=>{
          const dia = i+1;
          const cs  = porDia[dia]||[];
          const hoje= new Date();
          const isHoje = mes.y===hoje.getFullYear()&&mes.m===hoje.getMonth()&&dia===hoje.getDate();
          const cor = cs.length>0 ? (VC[calcVenc(cs[0].dataVenc)]||"#16a34a") : "transparent";
          return (
            <div key={dia} style={{ textAlign:"center",padding:"6px 2px",borderRadius:8,
                                    background:isHoje?"var(--t-pri,#16a34a)18":"transparent",
                                    border:`1px solid ${cs.length>0?cor+"44":"transparent"}`,
                                    position:"relative" }}>
              <span style={{ fontSize:13,fontWeight:isHoje?800:400,
                             color:isHoje?"var(--t-pri,#16a34a)":"var(--t-txt,#111)" }}>{dia}</span>
              {cs.length>0&&(
                <div style={{ position:"absolute",bottom:2,left:"50%",transform:"translateX(-50%)",
                              width:6,height:6,borderRadius:"50%",background:cor }}/>
              )}
            </div>
          );
        })}
      </div>

      {/* Lista do mês */}
      {vencMes.length===0?(
        <p style={{ textAlign:"center",color:"#aaa",padding:"20px 0",fontSize:14 }}>
          Nenhum vencimento neste mês
        </p>
      ):vencMes.map(c=>{
        const pago = !!pags[c._id];
        return (
          <div key={c._id} style={{ background:"var(--t-card,#fff)",borderRadius:12,
                                     marginBottom:8,border:"1px solid var(--t-bor,#e5e7eb)",
                                     padding:"11px 13px",opacity:pago?.6:1 }}>
            <div style={{ display:"flex",alignItems:"center",justifyContent:"space-between" }}>
              <div style={{ flex:1,minWidth:0 }}>
                <p style={{ margin:"0 0 2px",fontSize:14,fontWeight:800,
                            color:"var(--t-txt,#111)",textDecoration:pago?"line-through":"none" }}>
                  {c.nome}
                </p>
                <p style={{ margin:0,fontSize:12,color:"#888" }}>
                  {fmtDate(c.dataVenc)}{c.plano&&` • ${c.plano}`}{c.valor&&` • ${fmtBRL(c.valor)}`}
                </p>
              </div>
              <div style={{ display:"flex",gap:6,alignItems:"center",flexShrink:0 }}>
                <BadgeVenc dataVenc={c.dataVenc}/>
                <button onClick={()=>{
                  const p={...pags}; pago?delete p[c._id]:p[c._id]=new Date().toISOString();
                  lsSet(PAG_KEY,p);
                }}
                  style={{ padding:"5px 10px",borderRadius:20,border:"none",cursor:"pointer",
                           background:pago?"#f0fdf4":"#f3f4f6",color:pago?"#16a34a":"#888",
                           fontSize:12,fontWeight:700 }}>
                  {pago?"✅ Pago":"Pagar"}
                </button>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}

// ═══════════════════════════════════════
//  APP PRINCIPAL
// ═══════════════════════════════════════
export default function App() {
  const [tab,       setTab]       = useState("home");
  const syncMode = () => lsGet(SYNC_MODE_KEY)||"manual";
  const [clientes,  setClientes]  = useState(()=>lsGet(LOCAL_KEY)||{});
  const [busca,     setBusca]     = useState("");
  const [filtro,    setFiltro]    = useState("Cobrança");
  const [showModal, setShowModal] = useState(false);
  const [editC,     setEditC]     = useState(null);
  const [showImp,   setShowImp]   = useState(false);
  const [showTemas, setShowTemas] = useState(false);
  const [analise,   setAnalise]   = useState(null);
  const [novos,     setNovos]     = useState(0);
  const [syncSt,    setSyncSt]    = useState("idle");
  const [lastSync,  setLastSync]  = useState(null);
  const [salvando,  setSalvando]  = useState(false);
  const [toast,     setToast]     = useState(null);
  const syncRef = useRef(null);

  useEffect(()=>{ aplicarTema(getTema()); },[]);

  const toast$ = (msg, tipo="ok") => { setToast({msg,tipo}); setTimeout(()=>setToast(null),3000); };

  // ── Sync nuvem
  const verificarNuvem = useCallback(async (silencioso=false)=>{
    if(!silencioso) setSyncSt("syncing");
    const cloud = await gistGet();
    if(!cloud){ setSyncSt("erro"); return; }
    setSyncSt("ok"); setLastSync(new Date());

    const local    = lsGet(LOCAL_KEY)||{};
    const imported = lsGet(IMP_KEY)||[];
    const result   = analisarImportacao(cloud.clientes||{}, local, imported);

    // Auto-aplica atualizados
    if(result.atualizados.length>0){
      const loc2 = {...local};
      let n=0;
      result.atualizados.forEach(raw=>{
        const cc=normalizarCloudCliente(raw); // normaliza dataVenc → ISO, tel sem +55
        const lid = Object.keys(loc2).find(k=>loc2[k]._cloudId===cc._cloudId);
        if(lid){ loc2[lid]={...loc2[lid],...cc,venc:calcVenc(cc.dataVenc),_syncedAt:new Date().toISOString()}; n++; }
      });
      if(n>0){
        setClientes(loc2); lsSet(LOCAL_KEY,loc2);
        if(!silencioso) toast$(`🔄 ${n} atualizado${n>1?"s":""}  da nuvem`,"info");
        const r2 = analisarImportacao(cloud.clientes||{},loc2,imported);
        setAnalise(r2); setNovos(r2.novos.length); return;
      }
    }
    setAnalise(result);

    const pendentes = result.novos.length + result.atualizados.length;
    setNovos(pendentes);

    // Modo AUTO: importa novos diretamente sem confirmação
    if(syncMode()==="auto" && result.novos.length>0){
      const local2 = {...lsGet(LOCAL_KEY)||{}};
      const imp2   = new Set(lsGet(IMP_KEY)||[]);
      result.novos.forEach(raw=>{
        const cc=normalizarCloudCliente(raw); // normaliza dataVenc → ISO, tel sem +55
        const id=genId();
        local2[id]={...cc,venc:calcVenc(cc.dataVenc),origem:"nuvem",
                    importadoEm:new Date().toISOString(),_syncedAt:new Date().toISOString(),_id:id};
        imp2.add(cc._cloudId);
      });
      setClientes(local2); lsSet(LOCAL_KEY,local2); lsSet(IMP_KEY,Array.from(imp2));
      const r3=analisarImportacao(cloud.clientes||{},local2,Array.from(imp2));
      setAnalise(r3); setNovos(r3.novos.length+r3.atualizados.length);
      if(!silencioso) toast$(`⚡ ${result.novos.length} importado${result.novos.length>1?"s":""} automaticamente!`,"info");
      return;
    }

    if(!silencioso&&pendentes>0)
      toast$(`☁️ ${pendentes} pendente${pendentes>1?"s":""} na nuvem!`,"info");
  },[]);

  useEffect(()=>{
    verificarNuvem(false);
    syncRef.current=setInterval(()=>verificarNuvem(true),SYNC_MS);
    return ()=>clearInterval(syncRef.current);
  },[verificarNuvem]);

  // ── Importar
  const handleImportar = async sel=>{
    if(!sel.length) return;
    const local  = {...clientes};
    const imp    = new Set(lsGet(IMP_KEY)||[]);
    sel.forEach(raw=>{
      const cc = normalizarCloudCliente(raw); // normaliza dataVenc → ISO, tel sem +55
      const existeId = Object.keys(local).find(k=>local[k]._cloudId===cc._cloudId);
      const id = existeId||genId();
      const base = existeId?local[existeId]:{};
      local[id] = { ...base,...cc, venc:calcVenc(cc.dataVenc),
                    origem:"nuvem", importadoEm:base.importadoEm||new Date().toISOString(),
                    _syncedAt:new Date().toISOString(), _id:id };
      imp.add(cc._cloudId);
    });
    setClientes(local); lsSet(LOCAL_KEY,local); lsSet(IMP_KEY,Array.from(imp));
    setShowImp(false); setNovos(0);
    toast$(`✅ ${sel.length} cliente${sel.length>1?"s":""} importado${sel.length>1?"s":""}!`);
    setTimeout(()=>verificarNuvem(true),600);
  };

  // ── Salvar cliente
  const handleSalvar = async dados=>{
    const id  = editC?._id||genId();
    const iso = dmyToISO(dados.dataVenc)||dados.dataVenc;
    // Preserva campos da extensão que o app não edita
    const base = editC ? (clientes[id]||{}) : {};
    const payload = {
      ...base,          // preserva _cloudId, ts, fornecedor, renovadoAte, origem, etc
      ...dados,
      dataVenc: iso,
      venc: calcVenc(iso),
      updatedAt: new Date().toISOString(),
      ts: Date.now(),   // atualiza ts numérico também (compatível com a extensão)
      _id: id,
    };
    const local = {...clientes,[id]:payload};
    setClientes(local); lsSet(LOCAL_KEY,local);
    setShowModal(false); setEditC(null);
    // Salvar na nuvem
    setSalvando(true);
    const cloud = await gistGet()||{};
    const cloudClientes = {...(cloud.clientes||{})};
    cloudClientes[id]={...payload};
    await gistPatch({...cloud,clientes:cloudClientes});
    setSalvando(false);
    toast$(`✅ ${editC?"Atualizado":"Adicionado"}!`);
  };

  // ── Deletar
  const deletar = id=>{
    if(!confirm("Remover cliente?")) return;
    const local={...clientes}; delete local[id];
    setClientes(local); lsSet(LOCAL_KEY,local);
    toast$("🗑 Removido","info");
  };

  // ── Lista filtrada
  const arr = Object.values(clientes).filter(c=>{
    const q = norm(busca);
    if(q && !norm(c.nome).includes(q) && !norm(c.usuario||"").includes(q) &&
           !norm(c.tel||"").includes(q)) return false;
    return true;
  }).sort((a,b)=>{
    const O={vencido:0,hoje:1,amanha:2,"3dias":3,"":4};
    return (O[calcVenc(a.dataVenc)]??4)-(O[calcVenc(b.dataVenc)]??4);
  });

  const stats = arr.reduce((a,c)=>{
    const v=calcVenc(c.dataVenc);
    if(v==="vencido") a.vencidos++;
    else if(v==="hoje") a.hoje++;
    else if(v==="amanha") a.amanha++;
    else if(v==="3dias") a.dias3++;
    return a;
  },{vencidos:0,hoje:0,amanha:0,dias3:0});

  const syncLabel = syncSt==="syncing"?"🔄"
                   :syncSt==="erro"?"❌"
                   :lastSync?`☁️ ${lastSync.getHours().toString().padStart(2,"0")}:${lastSync.getMinutes().toString().padStart(2,"0")}`:"☁️";

  return (
    <div style={{ maxWidth:440,margin:"0 auto",minHeight:"100vh",
                  background:"var(--t-bg,#f0f2f5)",fontFamily:"var(--t-font,system-ui,sans-serif)",
                  position:"relative" }}>

      {/* ── HEADER */}
      <div style={{ position:"sticky",top:0,zIndex:100,
                    background:"var(--t-hdr,#fff)",
                    boxShadow:"0 1px 0 var(--t-bor,#e5e7eb)" }}>
        {/* Tabs */}
        <div style={{ display:"flex",alignItems:"center",padding:"0 6px" }}>
          {[
            {id:"home",      icon:"card",     label:"Home"},
            {id:"nuvem",     icon:"cloud",    label:"Nuvem"},
            {id:"calendario",icon:"calendar", label:"Calendário"},
            {id:"resumo",    icon:"chart",    label:"Resumo"},
          ].map(({id,icon,label})=>(
            <button key={id} onClick={()=>setTab(id)}
              style={{ flex:1,padding:"14px 4px 10px",border:"none",cursor:"pointer",
                       background:"transparent",color:tab===id?"var(--t-pri,#16a34a)":"var(--t-txt2,#aaa)",
                       fontSize:13,fontWeight:tab===id?800:500,fontFamily:"var(--t-font,inherit)",
                       borderBottom:`2.5px solid ${tab===id?"var(--t-pri,#16a34a)":"transparent"}`,
                       transition:"all .15s",display:"flex",alignItems:"center",
                       justifyContent:"center",gap:4,position:"relative" }}>
              {label}
              {id==="nuvem"&&novos>0&&(
                <span style={{ position:"absolute",top:6,right:6,
                               width:16,height:16,borderRadius:"50%",
                               background:"#ef4444",color:"#fff",
                               fontSize:9,fontWeight:900,
                               display:"flex",alignItems:"center",justifyContent:"center" }}>
                  {novos>9?"9+":novos}
                </span>
              )}
            </button>
          ))}
          {/* Sync + Gear */}
          <button onClick={()=>verificarNuvem(false)}
            style={{ background:"none",border:"none",cursor:"pointer",padding:"0 6px",
                     fontSize:14,color:"var(--t-txt2,#aaa)",flexShrink:0 }}>
            {syncLabel}
          </button>
          <button onClick={()=>setShowTemas(true)}
            style={{ background:"none",border:"none",cursor:"pointer",padding:"0 8px 0 2px",flexShrink:0 }}>
            <Ic n="gear" sz={20} col="var(--t-txt2,#aaa)"/>
          </button>
        </div>
      </div>

      {/* Sync bar */}
      {salvando&&(
        <div style={{ background:"var(--t-pri,#16a34a)",color:"#fff",textAlign:"center",
                      fontSize:12,padding:5,fontWeight:700 }}>
          ☁️ Salvando na nuvem...
        </div>
      )}

      {/* ── CONTEÚDO */}
      <div style={{ overflowY:"auto",height:"calc(100vh - 50px)" }}>

        {/* HOME */}
        {tab==="home"&&(
          <div style={{ padding:"12px 12px 100px" }}>

            {/* Banner nuvem */}
            {novos>0&&(
              <div onClick={()=>setTab("nuvem")}
                style={{ background:"var(--t-pri,#16a34a)",borderRadius:14,padding:"12px 14px",
                         marginBottom:12,cursor:"pointer",display:"flex",alignItems:"center",gap:12,
                         boxShadow:"0 3px 12px rgba(22,163,74,.3)" }}>
                <div style={{ width:38,height:38,borderRadius:10,background:"rgba(255,255,255,.2)",
                              display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0 }}>
                  <Ic n="download" sz={20} col="#fff"/>
                </div>
                <div style={{ flex:1 }}>
                  <p style={{ margin:"0 0 1px",fontSize:14,fontWeight:800,color:"#fff" }}>
                    {novos} novo{novos>1?"s":""} na nuvem!
                  </p>
                  <p style={{ margin:0,fontSize:12,color:"rgba(255,255,255,.8)" }}>
                    Toque para importar
                  </p>
                </div>
                <span style={{ color:"rgba(255,255,255,.7)",fontSize:20 }}>›</span>
              </div>
            )}

            {/* Busca */}
            <div style={{ display:"flex",alignItems:"center",gap:9,background:"var(--t-card,#fff)",
                          borderRadius:12,padding:"10px 14px",marginBottom:10,
                          boxShadow:"0 1px 4px rgba(0,0,0,.05)" }}>
              <Ic n="search" sz={16} col="#ccc"/>
              <input value={busca} onChange={e=>setBusca(e.target.value)}
                placeholder="Buscar cliente..."
                style={{ border:"none",background:"transparent",outline:"none",
                         fontSize:14,color:"var(--t-txt,#555)",flex:1,fontFamily:"var(--t-font,inherit)" }}/>
              {busca&&(
                <button onClick={()=>setBusca("")} style={{ background:"none",border:"none",
                  cursor:"pointer",padding:0,display:"flex",alignItems:"center" }}>
                  <Ic n="close" sz={14} col="#ccc"/>
                </button>
              )}
            </div>

            {/* Filtros */}
            <div style={{ display:"flex",gap:7,marginBottom:12 }}>
              {[
                {id:"Cobrança", icon:"card",  cor:"#f97316"},
                {id:"Cliente",  icon:"user",  cor:"#16a34a"},
                {id:"Contatos", icon:"users", cor:"#2563eb"},
              ].map(({id,icon,cor})=>(
                <button key={id} onClick={()=>setFiltro(id)}
                  style={{ flex:1,display:"flex",alignItems:"center",justifyContent:"center",
                           gap:5,padding:"9px 4px",borderRadius:10,border:"none",cursor:"pointer",
                           background:filtro===id?cor+"14":"var(--t-card,#fff)",
                           color:filtro===id?cor:"var(--t-txt2,#aaa)",
                           fontSize:12,fontWeight:filtro===id?700:500,
                           boxShadow:"0 1px 4px rgba(0,0,0,.05)",transition:"all .15s" }}>
                  <Ic n={icon} sz={14} col={filtro===id?cor:"var(--t-txt2,#aaa)"}/>
                  {id}
                </button>
              ))}
            </div>

            {/* Stats */}
            <div style={{ display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,marginBottom:12 }}>
              {[
                ["🔴 Atrasados", stats.vencidos, "#ef4444"],
                ["🟠 Hoje",      stats.hoje,    "#f97316"],
                ["🟣 3 Dias",    stats.dias3,   "#a855f7"],
                ["🟡 Amanhã",    stats.amanha,  "#eab308"],
              ].map(([label,val,cor])=>(
                <div key={label} style={{ background:"var(--t-card,#fff)",borderRadius:11,
                                          padding:"12px 14px",border:"1px solid var(--t-bor,#e5e7eb)",
                                          display:"flex",alignItems:"center",justifyContent:"space-between" }}>
                  <span style={{ fontSize:12,color:"var(--t-txt2,#888)" }}>{label}</span>
                  <span style={{ fontSize:24,fontWeight:900,color:cor,fontFamily:"var(--t-font,inherit)" }}>{val}</span>
                </div>
              ))}
            </div>

            {/* Cabeçalho lista */}
            <div style={{ display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:8 }}>
              <span style={{ fontSize:14,fontWeight:800,color:"var(--t-txt,#111)" }}>
                Clientes ({arr.length})
              </span>
              <button onClick={()=>verificarNuvem(false)}
                style={{ background:"none",border:"none",cursor:"pointer",fontSize:12,
                         color:"var(--t-txt2,#aaa)",display:"flex",alignItems:"center",gap:4 }}>
                <Ic n="refresh" sz={13} col="var(--t-txt2,#aaa)"/> Atualizar
              </button>
            </div>

            {/* Lista */}
            {arr.length===0?(
              <div style={{ textAlign:"center",padding:"40px 20px",color:"#aaa" }}>
                <div style={{ fontSize:48,marginBottom:10 }}>👥</div>
                <p style={{ margin:0,fontSize:15,fontWeight:700 }}>Nenhum cliente ainda</p>
                <p style={{ margin:"6px 0 0",fontSize:13 }}>
                  {novos>0?"Toque no banner para importar da nuvem":"Adicione pelo botão +"}
                </p>
              </div>
            ):(
              arr.map(c=>(
                <CardCliente key={c._id} c={c}
                  onEdit={c=>{ setEditC(c); setShowModal(true); }}
                  onDelete={deletar}
/>
              ))
            )}
          </div>
        )}

        {tab==="nuvem"&&(
          <AbaNuvem
            analise={analise}
            syncSt={syncSt}
            lastSync={lastSync}
            totalLocal={Object.keys(clientes).length}
            onImportar={handleImportar}
            onSyncNow={()=>verificarNuvem(false)}
          />
        )}
        {tab==="calendario"&&(
          <AbaCalendario arr={arr} onEdit={c=>{ setEditC(c); setShowModal(true); }} onDelete={deletar}/>
        )}
        {tab==="resumo"&&<AbaResumo arr={arr}/>}
      </div>

      {/* FAB */}
      <button onClick={()=>{ setEditC(null); setShowModal(true); }}
        style={{ position:"fixed",bottom:22,right:16,width:54,height:54,borderRadius:"50%",
                 background:"var(--t-fab,linear-gradient(135deg,#16a34a,#15803d))",
                 border:"none",cursor:"pointer",zIndex:200,
                 display:"flex",alignItems:"center",justifyContent:"center",
                 boxShadow:"0 4px 18px rgba(0,0,0,.25)",transition:"transform .15s" }}>
        <Ic n="plus" sz={26} col="#fff"/>
      </button>

      {/* TOAST */}
      {toast&&(
        <div style={{ position:"fixed",top:58,left:12,right:12,maxWidth:416,margin:"0 auto",zIndex:500,
                      background:toast.tipo==="erro"?"#ef4444":toast.tipo==="info"?"#2563eb":"#16a34a",
                      color:"#fff",borderRadius:12,padding:"12px 16px",
                      boxShadow:"0 4px 20px rgba(0,0,0,.25)",fontSize:14,fontWeight:700,
                      display:"flex",alignItems:"center",gap:8 }}>
          {toast.msg}
        </div>
      )}

      {/* MODAIS */}
      {showModal&&(
        <ModalCliente clienteEdit={editC} onSalvar={handleSalvar} onFechar={()=>{ setShowModal(false); setEditC(null); }}/>
      )}
      {showImp&&analise&&(
        <PainelImport analise={analise} onImportar={handleImportar} onFechar={()=>setShowImp(false)}/>
      )}
      {showTemas&&(
        <ModalTemas onFechar={()=>{ setShowTemas(false); aplicarTema(getTema()); }}/>
      )}

      <style>{`
        * { box-sizing:border-box; -webkit-tap-highlight-color:transparent; }
        body { margin:0; padding:0; }
        button:active { opacity:.8; transform:scale(.97); }
        input,textarea { -webkit-appearance:none; }
        ::-webkit-scrollbar { width:0; }
        @keyframes wppPulse {
          0%,100% { transform:scale(1); box-shadow:0 2px 8px currentColor44; }
          50% { transform:scale(1.05); box-shadow:0 4px 14px currentColor88; }
        }
      `}</style>
    </div>
  );
}
